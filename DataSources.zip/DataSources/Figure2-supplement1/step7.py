import MDAnalysis as mda
import pandas as pd
import numpy as np
import matplotlib
params = {'font.size': 10, 'font.family': 'Times New Roman', 'mathtext.fontset': 'stix'}
matplotlib.rcParams.update(params)
import matplotlib.pyplot as plt

u = mda.Universe('../Figure2/step1.gro')
prot = u.select_atoms('name CA')
PL_nres = u.select_atoms('resname POPC').n_residues
TG_nres = u.select_atoms('resname TRIO').n_residues

def cal_sum(df):
    TGg = df[[11]]
    TGt = df[[12,13,14,15,16,17,18,19,20,21,22,23]].sum(axis=1)
    return TGg, TGt

s1 = []; s2 = []
for i in ['00', '01', '02', '03']:
    df = pd.read_pickle('../Figure2/step4.' + i + '.pkl')
    TGg, TGt = cal_sum(df)
    x = np.arange(len(TGg))
    x += prot.resids[0]

    TGg /= (TG_nres*1)
    TGt /= (TG_nres*12)
    
    s1.append(TGg)
    s2.append(TGt)

seq = prot.residues.sequence().seq[0:len(x)]
new = np.array([seq[i] + str(x[i]) for i in range(len(x))])

### TG glycerol
avg_g = np.average(s1, axis=0)
ste_g = np.std(s1, axis=0) / 2

### TG tail atoms
avg_t = np.average(s2, axis=0)
ste_t = np.std(s2, axis=0) / 2

fig, ax = plt.subplots(figsize=(6, 3))
bA = np.isin(x, [36, 40, 43, 163, 166, 170, 240, 244, 253, 257])
xxx = [0, 1, 2, 5, 6, 7, 10, 11, 12, 13]
ax.set_xticks(xxx)
ax.set_xticklabels(new[bA], rotation=90)

ax.plot(xxx, avg_g[bA] * 1e3, marker='o', color='black', label='glycerol')
ax.plot(xxx, avg_t[bA] * 1e3, marker='*', color='black', ls='--', label='tail')

bA = np.isin(x, [36, 40, 43])
ax.plot([0, 1, 2], avg_g[bA] * 1e3, marker='o', color='C2')
ax.plot([0, 1, 2], avg_t[bA] * 1e3, marker='*', color='C2', ls='--')

bA = np.isin(x, [163, 166, 170])
ax.plot([5, 6, 7], avg_g[bA] * 1e3, marker='o', color='C3')
ax.plot([5, 6, 7], avg_t[bA] * 1e3, marker='*', color='C3', ls='--')

bA = np.isin(x, [240, 244, 253, 257])
ax.plot([10,11,12,13], avg_g[bA] * 1e3, marker='o', color='C4')
ax.plot([10,11,12,13], avg_t[bA] * 1e3, marker='*', color='C4', ls='--')

ax.set_ylim([0, 1.4])
ax.set_ylabel('$||s_A|| \; (\\times 10^3)$', fontsize=14)
ax.legend(frameon=False)
fig.tight_layout()
fig.savefig('step7.pdf')

