import numpy as np
import matplotlib
matplotlib.use('PDF')
params = {'font.size': 10, 'font.family': 'Times New Roman', 'mathtext.fontset': 'stix'}
matplotlib.rcParams.update(params)
import matplotlib.pyplot as plt

fig, ax = plt.subplots(figsize=(3.25, 2.5))

d = np.loadtxt('diffusion.dat')
### UNIT: 1e-4 x A^2/ps = cm2/s

x = np.array([17.5, 52.5, 70 + 15]) / 10
ax.axvline(3.5, color='black', ls='--')
ax.axvline(7.0, color='black', ls='--')
ax.axvline(10,  color='black', ls='--')
ax.errorbar(x, d[:,0][6:9] * 1e-4, d[:,1][6:9] * 1e-4, label='TG')
ax.errorbar(x, d[:,0][0:3] * 1e-4, d[:,1][0:3] * 1e-4, label='PL (c)')

x = np.array([11,  52.5, 70 + 15]) / 10
ax.errorbar(x, d[:,0][3:6] * 1e-4, d[:,1][3:6] * 1e-4, label='PL (l)')

ax.set_xlim([0, 11])

ax.set_xlabel('$r$ ($nm$)', fontsize=14)
ax.set_ylabel('$D$ ($cm^2 / s$)', fontsize=14)

box = ax.get_position()
fig.legend(loc='center right', fontsize=8, frameon=False)
fig.tight_layout()
fig.subplots_adjust(right=0.75)
fig.savefig('diffusion.pdf')

