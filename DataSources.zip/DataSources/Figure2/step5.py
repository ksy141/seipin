import MDAnalysis as mda
import pandas as pd
import numpy as np
import matplotlib
params = {'font.size': 10, 'font.family': 'Times New Roman', 'mathtext.fontset': 'stix'}
matplotlib.rcParams.update(params)
import matplotlib.pyplot as plt

u = mda.Universe('step1.gro')
prot = u.select_atoms('name CA')
PL_nres = u.select_atoms('resname POPC').n_residues
TG_nres = u.select_atoms('resname TRIO').n_residues

def cal_sum(df):
    PL = df[[0,1,2,3,4,5,6,7,8,9,10]].sum(axis=1)
    TG = df[[11,12,13,14,15,16,17,18,19,20,21,22,23]].sum(axis=1)
    return PL, TG

def cal_max(df):
    PL = df[[0,1,2,3,4,5,6,7,8,9,10]].max(axis=1)
    TG = df[[11,12,13,14,15,16,17,18,19,20,21,22,23]].max(axis=1)
    return PL, TG

fig, ax = plt.subplots(figsize=(6.75, 2.8))

sPL = []; sTG = []
for i in ['00', '01', '02', '03']:
    df = pd.read_pickle('step4.' + i + '.pkl')
    PL, TG = cal_sum(df)
    x = np.arange(len(PL))
    x += prot.resids[0]

    PL /= PL_nres
    TG /= TG_nres
    
    sPL.append(PL)
    sTG.append(TG)


### PL
avg = np.average(sPL, axis=0)
ste = np.std(sPL, axis=0) / 2
avg *= 1e3
ste *= 1e3
ax.plot(x, avg, label='PL', color='black')
ax.fill_between(x, avg-ste, avg+ste, color='black', alpha=0.3)
np.savetxt('step5_PL.dat', np.transpose([x, avg, ste]), fmt='%5d %8.5f %8.5f')

### TG
avg = np.average(sTG, axis=0)
ste = np.std(sTG, axis=0) / 2
avg *= 1e3
ste *= 1e3
ax.plot(x, avg, label='TG', color='C1')
ax.fill_between(x, avg-ste, avg+ste, color='C1', alpha=0.3)
np.savetxt('step5_TG.dat', np.transpose([x, avg, ste]), fmt='%5d %8.5f %8.5f')

#### N-TMD
#bA = (33 <= x) & (x <= 46)
#ax.plot(x[bA], avg[bA], color='C2')
#
#### HH
#bA = (161 <= x) & (x <= 174)
#ax.plot(x[bA], avg[bA], color='C3')
#
#### C-TMD
#bA = (238 <= x) & (x <= 251)
#ax.plot(x[bA], avg[bA], color='C4')

ax.legend(frameon=False)
ax.set_xlabel('residue', fontsize=12)
ax.set_ylabel('$||s|| \; (\\times 10^3)$', fontsize=14)
fig.tight_layout()
fig.savefig('step5.pdf')
