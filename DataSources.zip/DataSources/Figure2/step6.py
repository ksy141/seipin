import MDAnalysis as mda
import pandas as pd
import numpy as np
import matplotlib
params = {'font.size': 10, 'font.family': 'Times New Roman', 'mathtext.fontset': 'stix'}
matplotlib.rcParams.update(params)
import matplotlib.pyplot as plt

u = mda.Universe('step1.gro')
prot = u.select_atoms('name CA')
PL_nres = u.select_atoms('resname POPC').n_residues
TG_nres = u.select_atoms('resname TRIO').n_residues

def cal_sum(df):
    PL = df[[0,1,2,3,4,5,6,7,8,9,10]].sum(axis=1)
    TG = df[[11,12,13,14,15,16,17,18,19,20,21,22,23]].sum(axis=1)
    return PL, TG

sPL = []; sTG = []
for i in ['00', '01', '02', '03']:
    df = pd.read_pickle('step4.' + i + '.pkl')
    PL, TG = cal_sum(df)
    x = np.arange(len(PL))
    x += prot.resids[0]

    PL /= PL_nres
    TG /= TG_nres
    
    sPL.append(PL)
    sTG.append(TG)

### TG
avg = np.average(sTG, axis=0)
ste = np.std(sTG, axis=0) / 2
seq = prot.residues.sequence().seq[0:len(x)]
new = np.array([seq[i] + str(x[i]) for i in range(len(x))])

fig, ax = plt.subplots(figsize=(3.0, 1.8))
bA = (33 <= x) & (x <= 46)
ax.plot(x[bA], avg[bA] * 1e3, marker='o', color='C2')
ax.set_xticks(x[bA])
ax.set_xticklabels(new[bA], rotation=90, fontsize=10)
ax.set_ylabel('$||s|| \; (\\times 10^3)$', fontsize=14)
fig.tight_layout()
fig.savefig('step6_N.pdf')

fig, ax = plt.subplots(figsize=(3.0, 1.8))
bA = (161 <= x) & (x <= 174)
ax.plot(x[bA], avg[bA] * 1e3, marker='o', color='C3')
ax.set_xticks(x[bA])
ax.set_xticklabels(new[bA], rotation=90, fontsize=10)
ax.set_ylabel('$||s|| \; (\\times 10^3)$', fontsize=14)
fig.tight_layout()
fig.savefig('step6_HH.pdf')

fig, ax = plt.subplots(figsize=(3.0, 1.8))
bA = (238 <= x) & (x <= 251)
ax.plot(x[bA], avg[bA] * 1e3, marker='o', color='C4')
ax.set_xticks(x[bA])
ax.set_xticklabels(new[bA], rotation=90, fontsize=10)
ax.set_ylabel('$||s|| \; (\\times 10^3)$', fontsize=14)
fig.tight_layout()
fig.savefig('step6_C.pdf')


