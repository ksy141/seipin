import numpy as np
import matplotlib
matplotlib.use('PDF')
params = {'font.size': 10, 'font.family': 'Times New Roman', 'mathtext.fontset': 'stix'}
matplotlib.rcParams.update(params)
import matplotlib.pyplot as plt

fig, ax = plt.subplots(figsize=(2.5, 2.5))

d = np.loadtxt('ENM.02/clust.dat')
ax.plot(d[:,0] * 500000 / 1e6, d[:,1], color='red', label='seipin oligomer')

d = np.loadtxt('noseipin/clust.dat')
ax.plot(d[:,0] * 50000 / 1e6, d[:,1], color='black', label='no seipin')

d = np.loadtxt('ENM.02.ONE/clust.dat')
ax.plot(d[:,0] * 500000 / 1e6, d[:,1], color='C2', label='one subunit')

ax.set_xlim([0, 250])
ax.set_ylim([0, 100])
ax.set_xlabel('Nsteps (M)', fontsize=12)
ax.set_ylabel('Nucleation %', fontsize=12)

ax.legend(frameon=False)
fig.tight_layout()
fig.savefig('plot.pdf')


