import numpy as np
import matplotlib
matplotlib.use('PDF')
params = {'font.size': 10, 'font.family': 'Times New Roman', 'mathtext.fontset': 'stix'}
matplotlib.rcParams.update(params)
import matplotlib.pyplot as plt

fig, ax = plt.subplots(figsize=(1.7, 1.7))
d = np.loadtxt('radius.dat')
every = 100
ax.plot(d[:,0][::every] * 50000 / 1e6, d[:,1][::every], color='C1')
ax.set_xlabel('Nsteps (M)')
ax.set_ylabel('D (nm)')
ax.set_ylim([10, 18])
ax.set_yticks([10, 14, 18])
fig.tight_layout()
fig.savefig('radius.pdf')



