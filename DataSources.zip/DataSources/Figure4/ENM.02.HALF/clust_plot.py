import numpy as np
import matplotlib
matplotlib.use('PDF')
params = {'font.size': 10, 'font.family': 'Times New Roman', 'mathtext.fontset': 'stix'}
matplotlib.rcParams.update(params)
import matplotlib.pyplot as plt

fig, ax1 = plt.subplots(figsize=(1.7, 1.7))
every = 10
d = np.loadtxt('clust.dat')
ax1.plot(d[:,0] * 500000 / 1e6, d[:,1], color='black', label='Nuc%')
ax1.axhline(10000, color='red', label='$k$')
#ax1.legend(frameon=False, fontsize=6)

ax2 = ax1.twinx()
ax2.plot(d[:,0][::every] * 500000 / 1e6, d[:,2][::every], color='red')
ax2.tick_params(axis='y', labelcolor='red')

ax1.set_xlabel('Nsteps (M)')
#ax1.set_ylabel('Nucleation %', fontsize=8)
#ax2.set_ylabel('$k$', color='red', fontsize=8)

ax1.set_xlim([0, 230])
ax1.set_ylim([0, 100])
ax2.set_ylim([0, 0.25])
fig.tight_layout()
fig.savefig('clust.pdf')



